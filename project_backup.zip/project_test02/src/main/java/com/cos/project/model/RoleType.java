package com.cos.project.model;

public enum RoleType {
	USER,ADMIN
}
