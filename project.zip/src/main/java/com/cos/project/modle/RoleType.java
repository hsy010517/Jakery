package com.cos.project.modle;

public enum RoleType {
	USER,ADMIN
}
